namespace RPAPI.Models
{
    public class GeoCoordinate
    {
        public int Id { get; set; }
        public double lat { get; set; }
        public double log { get; set; }
    }
}