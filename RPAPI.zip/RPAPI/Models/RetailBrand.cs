namespace RPAPI.Models
{
    public class RetailBrand
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public photo Logo { get; set; }
        public string WebSite { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
    }
}